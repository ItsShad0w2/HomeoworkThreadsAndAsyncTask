package com.example.homework_5;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity
{

    Button buttonStart, buttonStop, buttonMovingNext;
    private final String FILENAME = "sound.wav";
    private ThreadsActivity threadsActivity;
    private int resourceId;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonStart = findViewById(R.id.buttonStart);
        buttonStop = findViewById(R.id.buttonStop);
        buttonMovingNext = findViewById(R.id.buttonMovingNext);

        String filename = FILENAME.substring(0, FILENAME.length() - 4);
        resourceId = getResources().getIdentifier(filename, "raw", getPackageName());

        buttonStop.setEnabled(false);

        buttonStart.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Start();
            }
        });

        buttonStop.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Stop();
            }
        });

        buttonMovingNext.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Move();
            }
        });

        }

    public void Start()
    {
        if(threadsActivity == null)
        {
            threadsActivity = new ThreadsActivity(this, resourceId);
            Thread thread = new Thread(threadsActivity);
            thread.start();
            buttonStart.setEnabled(false);
            buttonStop.setEnabled(true);
        }
    }

    public void Stop()
    {
        if(threadsActivity != null)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false);
            builder.setTitle("Stopping the song");
            builder.setMessage("Are you certain on stopping the song?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    threadsActivity.stopSong();
                    threadsActivity = null;
                    buttonStart.setEnabled(true);
                    buttonStop.setEnabled(false);
                }
            });

            builder.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.dismiss();
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    public void Move()
    {
        if(threadsActivity != null)
        {
            threadsActivity.stopSong();
            threadsActivity = null;
            buttonStart.setEnabled(true);
            buttonStop.setEnabled(false);
        }

        Intent intent = new Intent(this, SecondMainActivity.class);
        startActivity(intent);
        finish();
    }
}