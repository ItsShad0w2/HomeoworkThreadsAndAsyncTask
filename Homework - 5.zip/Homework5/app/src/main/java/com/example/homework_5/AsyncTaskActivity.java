package com.example.homework_5;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.concurrent.atomic.AtomicBoolean;

public class AsyncTaskActivity extends AsyncTask<Void, Void, Void>
{
    private MediaPlayer mediaPlayer;

    private Context context;
    private int resourceId;

    public AsyncTaskActivity(Context context, int resourceId)
    {
        this.context = context.getApplicationContext();
        this.resourceId = resourceId;
    }

    @Override
    protected Void doInBackground(Void... voids)
    {
        mediaPlayer = MediaPlayer.create(this.context, resourceId);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        while (mediaPlayer != null && mediaPlayer.isPlaying() && !isCancelled())
        {
            try
            {
                Thread.sleep(1000);
            }
            catch (InterruptedException e)
            {
                Thread.currentThread().interrupt();
            }
        }

        return null;
    }

    @Override
    protected void onCancelled()
    {
        super.onCancelled();

        if(mediaPlayer != null)
        {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }

    }
}