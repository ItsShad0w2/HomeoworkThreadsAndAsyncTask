package com.example.homework_5;


import android.content.Context;
import android.media.MediaPlayer;

public class ThreadsActivity implements Runnable
{
    public MediaPlayer mediaPlayer;
    private Context context;
    private int resourceId;

   public ThreadsActivity(Context context, int resourceId)
   {
       this.context = context.getApplicationContext();
       this.resourceId = resourceId;
   }

    public void run()
    {
        mediaPlayer = MediaPlayer.create(this.context, resourceId);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();
    }

    public void stopSong()
    {
        mediaPlayer.stop();
        mediaPlayer.release();
    }
}

