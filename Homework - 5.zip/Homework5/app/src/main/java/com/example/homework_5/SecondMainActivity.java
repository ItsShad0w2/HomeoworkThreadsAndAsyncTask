package com.example.homework_5;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondMainActivity extends AppCompatActivity
{

    Button buttonSecondStart, buttonSecondStop, buttonMovingBackwards;
    private final String FILENAME = "sound.wav";
    private AsyncTaskActivity asyncTaskActivity;
    private int resourceId;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_main);

        buttonSecondStart = findViewById(R.id.buttonSecondStart);
        buttonSecondStop = findViewById(R.id.buttonSecondStop);
        buttonMovingBackwards = findViewById(R.id.buttonMovingBackwards);

        String filename = FILENAME.substring(0, FILENAME.length() - 4);
        resourceId = getResources().getIdentifier(filename, "raw", getPackageName());

        buttonSecondStart.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Start();
            }
        });

        buttonSecondStop.setOnClickListener(new View.OnClickListener(
        )
        {
            @Override
            public void onClick(View v)
            {
                Stop();
            }
        });

        buttonMovingBackwards.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Move();
            }
        });
    }

    public void Start()
    {
        if(asyncTaskActivity == null || asyncTaskActivity.getStatus() == AsyncTask.Status.FINISHED)
        {
            asyncTaskActivity = new AsyncTaskActivity(this, resourceId);
            asyncTaskActivity.execute();
            buttonSecondStart.setEnabled(false);
            buttonSecondStop.setEnabled(true);
        }
    }

    public void Stop()
    {
        if(asyncTaskActivity != null)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false);
            builder.setTitle("Stopping the song");
            builder.setMessage("Are you certain on stopping the song?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    asyncTaskActivity.cancel(true);
                    asyncTaskActivity = null;
                    buttonSecondStart.setEnabled(true);
                    buttonSecondStop.setEnabled(false);
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.dismiss();
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    public void Move()
    {
        if(asyncTaskActivity != null)
        {
            asyncTaskActivity.cancel(true);
            asyncTaskActivity = null;
            buttonSecondStart.setEnabled(true);
            buttonSecondStop.setEnabled(false);
        }

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}